<?php

namespace App\Http\Controllers;

use Carbon\Carbon;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Requests;
use App\Marche;
use App\March_Societe;
use App\Decompte;
use App\Avenant;
class marchesCtrl extends Controller
{

    
    public function getMarkets($year,$type){
    	
        $markets = Marche::all()->where('type_budget',$type)-> where('year',$year."");
        $marketsArray = array();
        foreach ($markets as $m ) {
            $marketsArray[] = array(
                "id" => $m->id,
                "objet"=>$m->objet,
                "montant" =>$m->montant,
                "date_ouverture_plis" => $m->date_ouverture_plis,
                "date_debut_travaux" => $m->date_debut_travaux,
                "date_fin_travaux" => $m->date_fin_travaux,
                "labo" => $m->labo->name_labo,
                "societe" => $m->societe->name_societe,
                "bet" => $m->bet->name_bet,
                "architecte" => $m->archi->name_archi,
                "maitreOuvrage" =>$m->maitre_ouvrage->name_maitre_ouvrage,
                "pourcentage_financier" =>$this->calculePourcentageFinancier($m),
                "pourcentage_travaux" =>$m->pourcentage_travaux,
                "somme_decomptes" => $m->sum_decomptes,
                "somme_avenants" => $m->sum_avenants
                );
        }

        return $marketsArray;
    }

    private function calculePourcentageFinancier($m)
    {
        $decs = $this->getDecomptes($m->id);
        $s = 0;
        
       foreach ($decs as $key => $value) {
           $s = intval($s)+intval($decs[$key]->montant);
       }
       $m->sum_decomptes = $s;
       $m->sum_avenants = $this->calculeAvenants($m);
        return round(100*($s/($m->montant+$m->sum_avenants))).'%';
    }
    private function calculeAvenants($m)
    {
        $aves = $this->getAvenants($m->id);
        $s = 0;
        foreach ($aves as $key => $value) {
            $s = intval($s)+intval($aves[$key]->montant);
        }

        return $s;
    }

    public function deleteMarket($id){
        $m = Marche::find($id);
        $m->delete();
        return 1;
    }


    public function postMarket(Request $request){
    	$marche = new Marche();
    	$param = $request->all();

    	$marche->year = $param['year'];
    	$marche->type_budget = $param['type_budget'];
    	$marche->objet = $param['objet'];
    	$marche->montant= $param['montant'];
        $date_ouverture_plis = new Carbon($param['date_ouverture_plis']);
        $date_debut_travaux = new Carbon($param['date_debut_travaux']);
        $marche->date_ouverture_plis = $date_ouverture_plis;
    	$marche->date_debut_travaux = $date_debut_travaux;
    	$date_fin_travaux = new Carbon($param['date_debut_travaux']);
        $date_fin_travaux->addDays(intval($param['duree']));
        $marche->date_fin_travaux = $date_fin_travaux;
        $marche->labo_id = $param['labo_id'];
        $marche->societe_id = $param["societe_id"];
        $marche->archi_id = $param['archi_id'];
        $marche->bet_id = $param['bet_id'];
        $marche->maitre_ouvrage_id = $param['maitre_ouvrage_id'];
        $marche->sum_decomptes = 0;
        $marche->percentage_financial = 0;
        $marche->pourcentage_travaux = 0;
        $marche->save();

        return 1;
    }

    public function getDecomptes($id)
    {
        return Decompte::where('marche_id',$id)->get();
    }
    public function getAvenants($id)
    {
        return Avenant::where('marche_id',$id)->get();
    }

    public function addDecompte(Request $req){

        $param = $req->all();
        $decompte = new Decompte();
        $decompte->marche_id = $param['marche_id'];
        $decompte->montant = $param['montant'];
        $decompte->save();

        return 1;

    }

    public function addAvenant(Request $req)
    {
            $param = $req->all();
            $av = new Avenant();
            var_dump($param);
            $av->marche_id = $param['marche_id'];
            $av->objet = $param['objet'];
            $av->montant = $param["montant"];
            $av->save();

            return 1;
    }
}



?>