<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Maitre_oeuvre extends Model
{
    //
}
