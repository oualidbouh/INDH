<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Maitre_ouvrage extends Model
{
    //
}
