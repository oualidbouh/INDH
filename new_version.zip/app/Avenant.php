<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Avenant extends Model
{
    //
}
