<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Marche_Societe extends Model
{
    //
}
