
app.controller("marketDetailsCtrl",function ($scope,$location,$rootScope,$http,$filter) {
	$scope.montant = "";
	$scope.avenant ="";
		if($rootScope.year == undefined && $rootScope.budgetType == undefined){
			$location.path("/");
		}else{

					$http.get("/market/"+$rootScope.market.id+"/decomptes")
						.success(function(res) {
							$rootScope.market.decomptes = res;
							console.log($rootScope.market)
						})
						.error(function () {
							alert('error')
						});

					$http.get("/market/"+$rootScope.market.id+"/avenants")
						.success(function(res) {
							$rootScope.market.avenants = res;
							console.log($rootScope.market)
						})
						.error(function () {
							alert('error')
						});

					$scope.updateMarketsDetails = function(rgument) {
						if($scope.montant != ""){
							$rootScope.market.somme_decomptes += parseInt($scope.montant);
						}
						if(JSON.stringify($scope.avenant) != "{}"){
							$rootScope.market.somme_avenants += parseInt($scope.avenant.montant);
						}
						var p = 100*Math.round($rootScope.market.somme_decomptes/(parseInt($rootScope.market.montant)+parseInt($rootScope.market.somme_avenants)));
						$rootScope.market.pourcentage_financier = p+"%";
					}

					$scope.addDecompte = function(){
						if($scope.montant != ""){
							$http.post('/market/newDecompte',{"marche_id":$rootScope.market.id,"montant":$scope.montant})
							.success(function(res){
								$rootScope.market.decomptes.push({"montant":$scope.montant,"created_at": $filter('date')(new Date(),"yyyy-MM-dd hh:mm:ss")});
								
								$scope.updateMarketsDetails();
								$scope.montant="";
							}).error(function() {
								alert('error adding decomptes')
							});
						}else{
							alert("valeur de decompte non valide")
						}
					};
					$scope.avenant = {};
					$scope.addAvenant = function(){
						if($scope.avenant.objet != "" && $scope.avenant.objet !="" ){
							$http.post('/market/newAvenant',{"marche_id":$rootScope.market.id,"objet":$scope.avenant.objet,"montant" : $scope.avenant.montant})
							.success(function(res){
								var d= $filter('date');
								console.log($scope.avenant)
								$rootScope.market.avenants.push({"objet":$scope.avenant.objet,"montant":$scope.avenant.montant,"created_at": d(new Date(),"yyyy-MM-dd hh:mm:ss")});
								$scope.updateMarketsDetails();
								$scope.avenant = {};
							}).error(function() {
								alert('error adding avenants')
							});
						}else{
							alert('valeur de l\'avenant  non valide')
						}
					}	
		}

		$scope.deleteMarche= function(){
			$http.delete('/delete/marche/'+$rootScope.market.id).success(function(res){
				 $location.path("/");
				 console.log(res);
			}).error(function(){
				alert('erreur pendant le suppression du marché');
			});
		}
});