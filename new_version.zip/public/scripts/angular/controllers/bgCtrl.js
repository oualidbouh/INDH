app.controller("bgCtrl",function ($scope,$rootScope) {
	/*$scope.cols = [0, 1, 1, 1];
	$scope.laboratoires = $scope.bets = $scope.societes = $scope.maitres = $scope.architectes = [{name:"med"},{name:"med"},{name:"med"},{name:"med"},];*/








});
