app.controller("indhCtrl",function ($scope) {
	$scope.cols = [1, 1, 1, 1];
});