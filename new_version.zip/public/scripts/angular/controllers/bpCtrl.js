app.controller("bpCtrl",function ($scope) {
	$scope.cols = [0, 1, 1, 1];
});