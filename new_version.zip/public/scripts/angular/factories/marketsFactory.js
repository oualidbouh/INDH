app.factory('marketsFactory',function($http){
	return {
		getMarkets:function (year,type) {
			return $http.get("/markets/"+year+"/"+type);
		},
		postMarket:function(market){
			return $http.post("/marche",market);
		}
	}
})