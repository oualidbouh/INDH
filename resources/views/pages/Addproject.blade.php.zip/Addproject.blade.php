<!DOCTYPE html>
<html>
<head>
	<title>Ajouter un Projet</title>
	<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  	<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />
	<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.5/angular.min.js"></script> 
	<style type="text/css">
		@media(min-width: 200px){
			.round-button {
				width: 20px;
			}
		}

		@media(min-width: 500px){
			.round-button {
				width:25px;
		}
	}
		@media(min-width: 700px){
			.round-button {
				width:40px;
			}
		}
	

		.round-button-circle {
			width: 100%;
			height:0;
			padding-bottom: 100%;
   			border-radius: 50%;
	  		overflow:hidden;
   		 	background: #4679BD; 
   		 	box-shadow: 0 0 3px gray;
	}
}
		.round-button-circle:hover {
			background:#30588e;
}
		.round-button a {
    		display:block;
			float:left;
			width:100%;
			padding-top:50%;
    		padding-bottom:50%;
			line-height:1em;
			margin-top:-0.5em;
    		text-align:center;
			color:#e2eaf3;
    		font-family:Verdana;
    		font-size:1.2em;
    		font-weight:bold;
    		text-decoration:none;
}
	</style>
</head>
<body ng-app>
	<div class="container">
		<form class="form-horizontal" role="form">
			<div class="form-group">
				<label for="projectTitle">Titre du Projet</label>
				<input type="text" class="form-control" name="projectTitle" id="projectTitle"/>
			</div>
			<div class="form-group">
				<label for="type">Type du projet</label>
				<select class="form-control">
					<option>INDH</option>
					<option>BP</option>
					<option>BG</option>
				</select>
			</div>
			<div class="form-group">
				<label for="budget">Budget du Projet</label>
				<input type="number" class="form-control" name="budget" id="budget"/>
			</div>
			<div class="form-group">
				<label for="date">Date d'ouverture des plis</label>
				<div class="bootstrap-iso">
       				<input class="form-control" id="dateOuverturePlis" name="dateOuverturePlis" placeholder="MM/DD/YYYY" type="text"/>
 				</div>
			</div>
			<div class="form-group">
				<div class="bootstrap-iso">
					<label>Date De début de travaux</label>
					<input class="form-control" id="dateDebutTravaux" name="dateDebutTravaux" placeholder="MM/DD/YYYY" type="text" />
				</div>
			</div>
			<div class="form-group">
				<div class="bootstrap-iso">
					<label>Date De fin de travaux</label>
					<input class="form-control" id="dateFinTravaux" name="dateFinTravaux" placeholder="MM/DD/YYYY" type="text" />
				</div>
			</div>
			<div>				
				<div class="form-group">
					<label>Liste des Architectes</label>
					<div class="row">
					<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
					<select class="form-control ">
						<option>Ayyachi</option>
						<option>Oualid</option>
					</select>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
					<div class="round-button">
						<div class="round-button-circle">
							<a href="#" class="round-button">
								+
							</a>
						</div>
					</div>
					</div>
					</div>
					</div>
			</div>
				<div>				
					<div class="form-group">
						<label>Liste des Laboratoires</label>
						<div class="row">
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
								<select class="form-control ">
									<option>lab1</option>
									<option>lab2</option>
								</select>
							</div>
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
							<div class="round-button">
								<div class="round-button-circle">
									<a href="#" class="round-button">
										+
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="form-group">
				<input type="submit" class="btn btn-success" value="Envoyer"></input>
			</div>
		</form>
	</div>
</body>
<script>
	/*Datepicker Date ouverture des plis*/
	$(document).ready(function(){
		var date_input=$('input[name="dateOuverturePlis"]'); //our date input has the name "date"
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'mm/dd/yyyy',
			container: container,
			todayHighlight: true,
			autoclose: true,
		});
		/*Datepicker Date debut des travaux*/
		var date_iput1=$('input[name="dateDebutTravaux"]');
		var container1=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent : "body";
		date_iput1.datepicker({
			format :'mm/dd/yyyy',
			container:container1,
			todayHighlight: true,
			autoclose : true,
		});

		/*Datepicker date fin des travaux*/
		var date_iput2=$('input[name="dateFinTravaux"]');
		var container2=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_iput2.datepicker({
			format :'mm/dd/yyyy',
			container:container2,
			todayHighlight: true,
			autoclose : true,
		});
	})
</script>
</html>