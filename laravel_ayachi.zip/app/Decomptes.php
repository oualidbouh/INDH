<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Decomptes extends Model
{
    //
}
